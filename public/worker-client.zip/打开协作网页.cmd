@echo off
cd /d "%~dp0"
node connect.mjs --web
pause
